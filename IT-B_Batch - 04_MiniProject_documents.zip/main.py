import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle

app = Flask(__name__)
model = pickle.load(open('parkinson.pkl', 'rb'))


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    features = [float(x) for x in request.form.values()]
    final_features = [np.array(features)]

    prediction = model.predict(final_features)
    print("final features", final_features)
    print("prediction:", prediction)
    output = prediction[0]
    print(output)
    if output == False:
        return render_template('result.html', prediction_text1='THE PATIENT DOES NOT HAVE PARKINSONS DISEASE')
    else:
        return render_template('result.html', prediction_text2='THE PATIENT HAVE PARKINSONS DISEASE')


if __name__ == "__main__":
    app.run(debug=True)
